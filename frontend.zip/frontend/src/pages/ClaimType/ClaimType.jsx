import styles from "./claimtype.module.css";

const ClaimType = () => {
  return <div className={`${styles.body}`}></div>;
};

export default ClaimType;
